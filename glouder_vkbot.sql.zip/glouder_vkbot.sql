-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 28 2020 г., 16:31
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `glouder_vkbot`
--

-- --------------------------------------------------------

--
-- Структура таблицы `chatList`
--
-- Создание: Окт 26 2020 г., 19:23
-- Последнее обновление: Окт 28 2020 г., 13:18
--

DROP TABLE IF EXISTS `chatList`;
CREATE TABLE `chatList` (
  `workId` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL,
  `executorId` int(11) DEFAULT NULL,
  `userChatId` int(11) DEFAULT NULL,
  `executorChatId` int(11) DEFAULT NULL,
  `resendUser` tinyint(1) DEFAULT '1',
  `resendExecutor` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `chatList`
--

INSERT INTO `chatList` (`workId`, `id`, `executorId`, `userChatId`, `executorChatId`, `resendUser`, `resendExecutor`) VALUES
(4, 540756692, 543225465, 11, 13, 1, 1),
(5, 212769883, NULL, 12, NULL, 1, 1),
(8, 157932037, NULL, 14, NULL, 1, 1),
(9, 211293364, NULL, 15, NULL, 1, 1),
(12, 132333426, NULL, 16, NULL, 1, 1),
(13, 198977956, 0, 18, 0, 1, 1),
(14, 540756692, 543225465, 19, 22, 1, 1),
(0, 540756692, 0, 20, 0, 1, 1),
(16, 540756692, 543225465, 23, 24, 1, 1),
(18, 292284733, NULL, 25, NULL, 1, 1),
(19, 278317859, NULL, 26, NULL, 1, 1),
(20, 165136541, NULL, 27, NULL, 1, 1),
(1, 295729678, NULL, 42, NULL, 1, 1),
(24, 399500927, NULL, 44, NULL, 1, 1),
(28, 212769883, 0, 45, 0, 1, 1),
(3, 193189077, NULL, 46, NULL, 1, 1),
(31, 200500461, NULL, 47, NULL, 1, 1),
(6, 208904974, NULL, 48, NULL, 1, 1),
(33, 225710471, NULL, 49, NULL, 1, 1),
(34, 25947218, NULL, 50, NULL, 1, 1),
(7, 141416832, NULL, 51, NULL, 1, 1),
(36, 213085724, NULL, 52, NULL, 1, 1),
(38, 593308590, NULL, 53, NULL, 1, 1),
(11, 147299324, NULL, 54, NULL, 1, 1),
(2, 295729678, 45695473, 58, 59, 1, 1),
(21, 540756692, NULL, 62, NULL, 1, 1),
(25, 147299324, 136625872, 64, 66, 1, 1),
(49, 403562139, 0, 67, 0, 1, 1),
(51, 208904974, NULL, 68, NULL, 1, 1),
(52, 27273861, NULL, 69, NULL, 1, 1),
(53, 146613741, NULL, 70, NULL, 1, 1),
(54, 212769883, 0, 71, 0, 1, 1),
(27, 80011540, NULL, 72, NULL, 1, 1),
(60, 179985890, NULL, 73, NULL, 1, 1),
(61, 193343175, NULL, 74, NULL, 1, 1),
(63, 296242844, NULL, 75, NULL, 1, 1),
(66, 333428655, 0, 77, 0, 1, 1),
(67, 212769883, NULL, 78, NULL, 1, 1),
(68, 477825880, NULL, 79, NULL, 1, 1),
(71, 141741865, NULL, 81, NULL, 1, 1),
(75, 184434343, NULL, 82, NULL, 1, 1),
(78, 556048701, NULL, 83, NULL, 1, 1),
(32, 613563975, NULL, 84, NULL, 1, 1),
(87, 137420091, NULL, 85, NULL, 1, 1),
(89, 257718208, NULL, 86, NULL, 1, 1),
(91, 78500404, 0, 87, 0, 1, 1),
(94, 264959482, NULL, 89, NULL, 1, 1),
(93, 227915400, NULL, 90, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `executorList`
--
-- Создание: Окт 26 2020 г., 19:23
-- Последнее обновление: Окт 28 2020 г., 13:30
--

DROP TABLE IF EXISTS `executorList`;
CREATE TABLE `executorList` (
  `id` int(11) DEFAULT NULL,
  `executor_id` int(11) DEFAULT NULL,
  `chat` int(11) DEFAULT NULL,
  `subject` text,
  `setpriceto` int(11) DEFAULT NULL,
  `waitto` int(11) DEFAULT NULL,
  `chatMessage` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `executorList`
--

INSERT INTO `executorList` (`id`, `executor_id`, `chat`, `subject`, `setpriceto`, `waitto`, `chatMessage`) VALUES
(413452302, 0, NULL, 'История,Обществознание,Экономика,Биология,Физкультура,Русский язык,Психология,Теория вероятностей и математическая статистика,Математика,', NULL, NULL, NULL),
(172300138, 1, NULL, 'Программирование,', NULL, NULL, NULL),
(384892612, 2, NULL, 'Английский язык,Русский язык,', NULL, NULL, NULL),
(45695473, 3, NULL, 'Высшая математика,Математика,Математический анализ,Дифференциальные уравнения,ТФКП,Теория вероятностей и математическая статистика,Линейная алгебра,Аналитическая геометрия,Уравнения математической физики,', NULL, NULL, NULL),
(8361371, 4, 0, 'Теоретическая механика,Сопротивление материалов,', NULL, 0, '0'),
(187687343, 5, NULL, 'Математика,Математический анализ,Линейная алгебра,Интегралы,Дифференциальные уравнения,Теоретическая механика,Сопротивление материалов,Физика,', NULL, NULL, NULL),
(845030, 6, NULL, 'Английский язык,Русский язык,История,', NULL, NULL, NULL),
(108565493, 7, NULL, 'Программирование,Русский язык,Английский язык,', NULL, NULL, NULL),
(82902284, 8, NULL, 'История,Обществознание,Философия,Право (абсолютно всё право),Государственное и муниципальное управление,Менеджмент,Маркетинг,Управление персоналом,Литература,Русский язык,Английский язык,Французский язык,Социология,Психология,Педагогика,Физкультура,', NULL, NULL, NULL),
(498977670, 9, NULL, 'Теоретическая механика,Сопротивление материалов,Физика,Математический анализ,Математика,Аналитическая геометрия,Интегралы,Инженерная графика,', NULL, NULL, NULL),
(110343914, 10, NULL, 'Право (абсолютно всё право),Криминалистика,Медицина,Психология,История,', NULL, NULL, NULL),
(113646923, 11, NULL, 'Инженерная графика,Сопротивление материалов,Теория конструкционных материалов (ТКМ),', NULL, NULL, NULL),
(239690133, 12, NULL, 'Программирование,Математический анализ,Математика,Аналитическая геометрия,Линейная алгебра,Дифференциальные уравнения,Интегралы,', NULL, NULL, NULL),
(29620545, 13, NULL, 'Право (абсолютно всё право),История,Криминалистика,', NULL, NULL, NULL),
(193343175, 14, NULL, 'Теория машин и механизмов (ТММ),Сопротивление материалов,Физика,Математика,Математический анализ,Аналитическая геометрия,Интегралы,Инженерная графика,Начертательная геометрия,Теоретическая механика,Программирование,Детали машин,', NULL, NULL, NULL),
(435193574, 15, NULL, 'История,Педагогика,Физика,Сопротивление материалов,Маркетинг,Менеджмент,Государственное и муниципальное управление,Философия,', NULL, NULL, NULL),
(341478917, 16, NULL, 'Инженерная графика,Компьютерная графика,Начертательная геометрия,Прикладная механика,Метрология,Основы конструирования приборов (ОКП),Детали машин,', NULL, NULL, NULL),
(111248280, 17, NULL, 'Управление персоналом,Государственное и муниципальное управление,Менеджмент,', NULL, NULL, NULL),
(528599670, 18, NULL, 'История,Литература,Психология,Международные отношения,Филология,Право (абсолютно всё право),Криминалистика,Биология,Медицина,Педагогика,Военная кафедра,', NULL, NULL, NULL),
(60652471, 19, NULL, 'Детали машин,Инженерная графика,Компьютерная графика,Начертательная геометрия,Теоретическая механика,Метрология,Теория конструкционных материалов (ТКМ),Детали машин,', NULL, NULL, NULL),
(507293609, 20, 0, 'Инженерная графика,Компьютерная графика,Начертательная геометрия,Математика,Математический анализ,Дифференциальные уравнения,Интегралы,Аналитическая геометрия,Линейная алгебра,Сопротивление материалов,Физика,', NULL, 0, '0'),
(204514724, 21, NULL, 'Теория машин и механизмов (ТММ),Сопротивление материалов,Метрология,Химия,Физика,Теоретическая механика,Инженерная графика,Компьютерная графика,Детали машин,', NULL, NULL, NULL),
(136625872, 22, NULL, 'Электротехника,', NULL, NULL, NULL),
(138364486, 23, NULL, 'Немецкий язык,', NULL, NULL, NULL),
(11357840, 24, NULL, 'Высшая математика,Математический анализ,Математика,Линейная алгебра,Дифференциальные уравнения,Теория вероятностей и математическая статистика,Программирование,Физика,', NULL, NULL, NULL),
(368259581, 25, NULL, 'Право (абсолютно всё право),', NULL, NULL, NULL),
(388862750, 26, NULL, 'Высшая математика,Физика,Математика,История,Право (абсолютно всё право),Социология,Философия,Детали машин,', NULL, NULL, NULL),
(242599310, 27, NULL, 'Химия,Английский язык,Математический анализ,', NULL, NULL, NULL),
(373565147, 28, NULL, 'Аналитическая геометрия,Высшая математика,Дискретная математика,Дифференциальные уравнения,Интегралы,Линейная алгебра,Логика,Математика,Математический анализ,ТФКП,Теория вероятностей и математическая статистика,Уравнения математической физики,Физика,Химия,', NULL, NULL, NULL),
(513757464, NULL, NULL, 'Затычка', NULL, NULL, NULL),
(331658531, NULL, NULL, 'Затычка', NULL, NULL, NULL),
(615435367, NULL, NULL, 'Затычка', NULL, NULL, NULL),
(20904658, NULL, NULL, 'Затычка', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `grandadmin`
--
-- Создание: Окт 26 2020 г., 19:23
-- Последнее обновление: Окт 28 2020 г., 13:29
--

DROP TABLE IF EXISTS `grandadmin`;
CREATE TABLE `grandadmin` (
  `id` int(11) DEFAULT NULL,
  `setworktypeto` int(11) DEFAULT NULL,
  `priceto` int(11) DEFAULT NULL,
  `setSideTo` int(11) DEFAULT NULL,
  `getExecutorList` int(11) DEFAULT NULL,
  `ApproximatePriceFrom` int(11) DEFAULT NULL,
  `ApproximatePriceTo` int(11) DEFAULT NULL,
  `massMessageto` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `grandadmin`
--

INSERT INTO `grandadmin` (`id`, `setworktypeto`, `priceto`, `setSideTo`, `getExecutorList`, `ApproximatePriceFrom`, `ApproximatePriceTo`, `massMessageto`) VALUES
(106541016, 20904658, 0, 0, 0, 0, 0, NULL),
(615435367, 0, 0, 0, 0, 0, 0, NULL),
(331658531, 0, 0, 0, 1, 11357840, 67, NULL),
(513757464, 0, 0, 0, 0, 0, 0, NULL),
(20904658, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `userList`
--
-- Создание: Окт 26 2020 г., 19:23
-- Последнее обновление: Окт 28 2020 г., 13:20
--

DROP TABLE IF EXISTS `userList`;
CREATE TABLE `userList` (
  `id` int(11) DEFAULT NULL,
  `subject` text,
  `status` text,
  `typeOfWork` text,
  `Task` text,
  `photos` text,
  `docs` text,
  `paymentCheck` text,
  `deadline` text,
  `workTime` text,
  `chat` int(11) DEFAULT NULL,
  `executor` int(11) DEFAULT NULL,
  `workId` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `executorPrice` float DEFAULT NULL,
  `executorStartPrice` text,
  `priceMarkup` text,
  `comment` text,
  `orderFinished` int(11) DEFAULT NULL,
  `sendingPaymentCheck` int(11) DEFAULT NULL,
  `paid` int(11) DEFAULT NULL,
  `userInChat` int(11) DEFAULT NULL,
  `whoIsAccepted` text,
  `whoIsDeclined` text,
  `commentFromExecutorWhenOrderIsAccepted` text,
  `askQuestion` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `userList`
--

INSERT INTO `userList` (`id`, `subject`, `status`, `typeOfWork`, `Task`, `photos`, `docs`, `paymentCheck`, `deadline`, `workTime`, `chat`, `executor`, `workId`, `price`, `executorPrice`, `executorStartPrice`, `priceMarkup`, `comment`, `orderFinished`, `sendingPaymentCheck`, `paid`, `userInChat`, `whoIsAccepted`, `whoIsDeclined`, `commentFromExecutorWhenOrderIsAccepted`, `askQuestion`) VALUES
(543225465, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(540756692, 'Аналитическая геометрия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-43.userapi.com/8qaUTA4w4hooRIFRagXkesi3gHhtSj4__9L1pA/4IixrI1ZIsg.jpg<--->https://sun9-58.userapi.com/YWfrCky2gh1q8ukGEWkoTQUpzc_XXPnaHAkQoA/6FXd4ONcbA0.jpg<--->https://sun9-72.userapi.com/QzZFa4p-jyeBDvKE4aTqweUpgQIAwNGdPow1-Q/-mUxXH7whm4.jpg<--->https://sun9-31.userapi.com/R09fevOWSbTCncOeJwQEPNsVZg0I-MfvwR-rkQ/3XeOWURuWX0.jpg<--->', '', 'https://sun9-8.userapi.com/nHtESB8z5OmDGcWy-qJTYzcotY89-_JfmGLi-A/McO62HUIM-0.jpg\n', 'Подтвердить', 'Не знаю', 11, 615435367, 4, 1000, 200, '500_543225465', '700_543225465', 'ТЕСТ', 1, 0, NULL, 1, '543225465', NULL, 'ТЕСТ ТЕСТ_543225465', NULL),
(212769883, 'Химия', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-23.userapi.com/0b-1_wk_p64Z4Ro9dTATegd7OsSpxqWDGR6rqg/kqh7YKH2wK0.jpg<--->https://sun9-13.userapi.com/rs0YppgAIzr_1qvEOtWR8bYliT9SYqU3sPMohA/4kF6ZKSCmP8.jpg<--->', '', NULL, 'Не знаю', 'Не знаю', 12, 615435367, 5, NULL, NULL, NULL, NULL, 'Номер 96 и 260\nПромокод: STUDIZBA', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(548653925, 'Электротехника', 'Personal', 'Домашняя работа', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(157932037, 'Прикладная механика', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc157932037_573026077?hash=5062489015dd3b7b99&dl=GE2TOOJTGIYDGNY:1602433213:ae1beaedcc3fa40c98&api=1&no_preview=1<--->https://vk.com/doc157932037_573026089?hash=5984e4a53fae138c92&dl=GE2TOOJTGIYDGNY:1602433213:0b2a5b3f4169ec723f&api=1&no_preview=1<--->https://vk.com/doc157932037_573026094?hash=74a1f39528eee6722b&dl=GE2TOOJTGIYDGNY:1602433213:339b2d0952996862dc&api=1&no_preview=1<--->', NULL, '18 10', 'Не знаю', 14, 615435367, 8, NULL, NULL, NULL, NULL, 'вариант 13, не уверен, что приложения именно к этой работе', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(211293364, 'Теория вероятностей и математическая статистика', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-69.userapi.com/YBmtXVyTuJIoJWsFwTIMAFvXVrM0op6WQ0yvHA/1qBsx9Ki2sI.jpg<--->https://sun9-24.userapi.com/2bLYue77Mdw6C2ykmM5JUxxmxy5f211_Q8meSQ/TDqXlS0wdAQ.jpg<--->', '', NULL, 'Не знаю', '12:00', 15, 615435367, 9, NULL, NULL, NULL, NULL, 'Добрый день!\nЕсть два домашних задания по теории случайных процессов (теория вероятности)\nПо срокам: первое дз было бы хорошо сдать через 1-2 недели, ну и второе чуть позже', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(263647007, '', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(132333426, '', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-73.userapi.com/GpAsjZkDDkytYnj9ElYfB6ialvzFYli6I6zECw/yvjBHfI9adY.jpg<--->https://sun9-44.userapi.com/XpN2_5cDcGEgS9rqKw74UzEy5_p_WWi-DIT_Sw/_SjldBlWtFE.jpg<--->https://sun9-49.userapi.com/rGqXocUo5knuze4njVKYXh7LLRvHWx_SEJbkpg/JaFej_RWJxY.jpg<--->https://sun9-76.userapi.com/qoxNuBOTIaHUdi-VUg5PyGBQ9yFCynKSoFnU0A/5K4Z8ZQtuEY.jpg<--->https://sun9-54.userapi.com/bHkx9S2LNYuskNSC2ERIur_I1KmLPCwpS8sgiQ/XguZRVHe97s.jpg<--->', '', NULL, 'Завтра', 'Не знаю', 16, 615435367, 12, NULL, NULL, NULL, NULL, 'Нужно решить все 10 номеров до 5-6 часов завтрашнего дня', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(198977956, 'Математика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-24.userapi.com/NYbUZXSu9zQIZG0c5WgPwOi8BWS7nUu0LiFK3g/JpdYV_oS1I4.jpg<--->', '', NULL, 'Сегодня', 'Идет сейчас!', 18, 615435367, 13, NULL, NULL, NULL, NULL, 'Хотябы 2 номера', 1, NULL, NULL, 1, NULL, '566565607', NULL, NULL),
(540756692, 'Аналитическая геометрия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-9.userapi.com/eCc4pokK8I0f9COOHk-sLoe5JggDAW0OQTnWZw/aC2P8b7nShU.jpg<--->', '', 'https://sun9-10.userapi.com/oJNfTJJL_34d_3nCF2vI6mfm7oLD49D0DioKRw/Gb2tKN-1q_Y.jpg\n', 'Не знаю', 'Не знаю', 19, 615435367, 14, 1000, 500, '500_543225465', '700_543225465,600_543225465', 'Необходимо выполнить все номера', 1, 0, NULL, 1, '543225465', NULL, 'Есть большой опыт в выполнении подобных работ._543225465', NULL),
(540756692, 'Аналитическая геометрия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Через неделю', 'Не знаю', 20, 615435367, 0, NULL, NULL, NULL, NULL, 'И', 1, NULL, NULL, 1, '543225465', '543225465', NULL, NULL),
(540756692, 'Аналитическая геометрия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-64.userapi.com/5EACw_Yl0d86Rr0CPWQaSyAB08ufq25TxEMKqQ/0fSOf1XnsO0.jpg<--->', '', NULL, 'Не знаю', 'Не знаю', 23, 615435367, 16, 700, 500, '500_543225465,500_543225465', '700_543225465,700_543225465', 'Необходимо выполнить все номера', 1, NULL, NULL, 1, ',543225465', NULL, 'Есть большой опыт в выполнении подобных работ_543225465,Есть большой опыт в выполнении подобных работ_543225465', NULL),
(295397973, 'Электротехника', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc295397973_570299424?hash=0695cd67b0babfb8ea&dl=GI4TKMZZG44TOMY:1602499965:6b43335a69e17aca84&api=1&no_preview=1<--->https://vk.com/doc295397973_570299422?hash=eab47ba3a8d5f94838&dl=GI4TKMZZG44TOMY:1602499965:4f2a9ac720cdd5c305&api=1&no_preview=1<--->https://vk.com/doc295397973_570299420?hash=48522e60e635c2e71c&dl=GI4TKMZZG44TOMY:1602499965:6d03c570d57d76eb61&api=1&no_preview=1<--->', NULL, 'Идет сейчас!', 'Не знаю', NULL, 615435367, 17, NULL, NULL, NULL, NULL, '5 группа 21 вариант', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(292284733, 'Высшая математика', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-44.userapi.com/JOCNR7lWOIoMEiubSXlLP5YuUzbXEXqdOZ9ceA/37rjGSl3TQg.jpg<--->', '', NULL, 'Сегодня', '15:30', 25, 615435367, 18, NULL, NULL, NULL, NULL, 'Вариант 26 , 5 задач до 23:00', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(278317859, 'Начертательная геометрия', 'Personal', 'Домашняя работа', 'Передать курьером', 'https://sun9-23.userapi.com/dE0i-2U9Iv9DTHsUj-a6UnA7tlyca0g26j1s1A/V-JJ-p7ERvw.jpg<--->https://sun9-6.userapi.com/nt2-vKn3F-lj5hOURH5mu6FMpOpAF4uZuD1A4A/KYSYGXvFGG0.jpg<--->', '', NULL, 'Завтра', 'Идет сейчас!', 26, 615435367, 19, NULL, NULL, NULL, NULL, 'Нужно начертить вариант 2 на ватмане а3 и сделать рамку по ГОСТу, на обратной стороне написать условия задачи 10 размером', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(165136541, 'Теоретическая механика', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-10.userapi.com/ZCGpcEzRhbBMUvVEC7dCzCGTLNmgNDaEH99FAg/xWjHWWtuVY4.jpg<--->', '', NULL, 'Через неделю', 'Не знаю', 27, 615435367, 20, NULL, NULL, NULL, NULL, 'Узнать цену заказа', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(295729678, 'Теория вероятностей и математическая статистика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Сегодня', 'Идет сейчас!', 42, 615435367, 1, NULL, NULL, NULL, NULL, 'test', 1, NULL, NULL, 1, NULL, NULL, NULL, 0),
(161076202, 'Теоретическая механика', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-15.userapi.com/AbNN4MW4Qt4hN18tyAbghN_cFx3iHfRYjsOtkw/31QeeqpPXPE.jpg<--->https://sun9-6.userapi.com/GwX8ONewL1-kOw5YlSZ0KzKbm6DGpbwoVIWCgQ/vSZ-Nh-wY3s.jpg<--->', '', NULL, 'Завтра', 'Идет сейчас!', NULL, 615435367, 22, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(258548369, 'Высшая математика', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc258548369_574948434?hash=953bc3d4222613407d&dl=GI2TQNJUHAZTMOI:1602864888:b25aff687cdec1160f&api=1&no_preview=1<--->', NULL, 'Идет сейчас!', 'Не знаю', 43, 615435367, 23, NULL, NULL, NULL, NULL, 'Нужно выполнить все нормера с фотографии. Надо пояснять все логические переходы теорией (кроме совсем очевидных).', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(399500927, 'Начертаетнльная геометрия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-35.userapi.com/Nshh7bA_bLB5wrMNANmd-cjnxCzaVjlXmRJ_eg/WRDwZ8ZxvmU.jpg<--->https://sun9-74.userapi.com/IACdlCp2VMDlou11rbCodnU3Yf5OL-xlnca18w/zcGDmthCQC0.jpg<--->', '', NULL, 'Не знаю', '10:15', 44, 615435367, 24, NULL, NULL, NULL, NULL, '2,3,4 номера', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(100474763, '', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(331658531, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(212769883, 'Аналитическая геометрия', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-9.userapi.com/mbp97B3kFKAZAy-AJFqxvtAuvN4axXlZn_vbvw/WbBJ_PNGJkE.jpg<--->https://sun9-52.userapi.com/GwHSe8GUYxA9XY49Pnu-H0_U75K-CUZCQNlQYg/qAa-dEt8n5o.jpg<--->', '', NULL, '19.10', 'Не знаю', 45, 615435367, 28, NULL, NULL, '500_11357840', '700_11357840', 'Вариант 27. Номера 6, 9-12', 1, NULL, NULL, 1, ',11357840', '507293609', 'Не указан_11357840', NULL),
(124303740, 'История', 'Personal', 'Реферат/Доклад/Отчет', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(193189077, 'Физкультура', 'Personal', 'Домашняя работа', 'Нормативы', NULL, NULL, NULL, 'Не знаю', 'Не знаю', 46, 615435367, 3, NULL, NULL, NULL, NULL, '', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(200500461, 'Химия', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-70.userapi.com/wteTrQqD8ioNl6YMXKA6bf6y9VqyLvrp7PvpYg/vX8btibo2ho.jpg<--->https://sun9-76.userapi.com/dSImLHQlYIh98qJoVctKlZZA2FBrKJrF6gvwuw/Hgq6VAVMB-c.jpg<--->https://sun9-15.userapi.com/OcWpaG_nbqzDBLPPQ0e7CjPVWOz1Psew5qR0ng/ZW9D3Uo8TP0.jpg<--->https://sun9-61.userapi.com/6eacwKnRD8wVk1TJSeVlzij7MzXkiFwTRNSNow/q-HjW1RYD48.jpg<--->https://sun9-55.userapi.com/x83oxas7uxrfb2y5n55Sg5-mJePHrlOqm09MOA/LDOq4PX3V2s.jpg<--->https://sun9-41.userapi.com/G1nsCbPHTaZxXvOnM8Rzi3Bn6Wg7bUUYaEYW-A/71h7N-LcXCY.jpg<--->https://sun9-25.userapi.com/HhY6iW_JMTQQ2V0XUJRZAeGIYeCVcga2P4SDEA/utSHMYrlO4c.jpg<--->https://sun9-47.userapi.com/wJ_8i8fRv67Ii0G6vSvWCbtdJBffrIUNWpS5oA/zQzTCyzdOhM.jpg<--->https://sun9-9.userapi.com/B-UB2RlwEUdOYFe7ZszBDYt2IN9hFLLzjTETQQ/fLyYcpTMqxI.jpg<--->', '', NULL, '30.10', 'Не знаю', 47, 615435367, 31, NULL, NULL, NULL, NULL, 'Номера 37,87,196,265,326,409,439,518,586', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(208904974, 'Химия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, '19.10', '13.00', 48, 615435367, 6, NULL, NULL, NULL, NULL, 'Задача 2', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(225710471, 'Электротехника', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-22.userapi.com/rj8Jk0_eLQX0gnNe-_wS9ms42VWccISLhgJj8Q/cY1kqtfvaec.jpg<--->', '', NULL, '21.10 8.30', '8.30', 49, 615435367, 33, NULL, NULL, NULL, NULL, 'Четвёртый номер', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(25947218, 'Финансы', 'Personal', 'Контрольная работа/РК', 'Прислать решение', '', 'https://vk.com/doc25947218_572365012?hash=5028751d02c292bd68&dl=GI2TSNBXGIYTQ:1603110056:285cb7253f93c69082&api=1&no_preview=1<--->https://vk.com/doc25947218_572365010?hash=457bd354c7ca942e95&dl=GI2TSNBXGIYTQ:1603110056:2ee7b60de7fe5d71a1&api=1&no_preview=1<--->', NULL, 'Не указан', 'Не знаю', 50, 615435367, 34, NULL, NULL, NULL, NULL, 'Ргр и контрольная работа номер 1 и номер 2, вариант 9, стоимость и сроки написания', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(141416832, 'Химия', 'Personal', 'Курсовая работа', 'Прислать решение', NULL, NULL, NULL, 'Не знаю', 'Не знаю', 51, 615435367, 7, NULL, NULL, NULL, NULL, 'Курсовая работа на тему\n Фенолформальдегидные олигомеры как модификаторы древесины\n Объём работы до 30 страниц\n Какая стоимость будет?', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(213085724, 'Экономика', 'Personal', 'Курсовая работа', 'Прислать решение', '', 'https://vk.com/doc213085724_571307489?hash=289a398029da54794d&dl=GIYTGMBYGU3TENA:1603116145:a8bb1ab8e7611d5510&api=1&no_preview=1<--->https://vk.com/doc213085724_571307592?hash=4c4783933ec96377f1&dl=GIYTGMBYGU3TENA:1603116145:c8cbeacffdd4895de4&api=1&no_preview=1<--->', NULL, '25.10.2020', 'Не знаю', 52, 615435367, 36, NULL, NULL, NULL, NULL, 'Нужно исправить ошибки в 1 документе(выделено красным) и сделать пункты 1.7 и 1.8 по мет.рекомендации', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(593308590, 'Теоретическая механика', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-17.userapi.com/3USA7tDfKAmYDgqqIC1XV6kCc9iVjjfHazaKSw/q5tyez8h5ic.jpg<--->https://sun9-64.userapi.com/AAgdWSCLBQZ_pmHsKypugK8AE4CJtaZjZlfJng/FM41H6v0AII.jpg<--->https://sun9-8.userapi.com/kCZzgzyyVZp37pWUkUpZN6E45cD4A84pATsyvQ/hr0HIWsWD1E.jpg<--->https://sun9-39.userapi.com/aDvrBohfTqCeaQ5yfnrod1pvJLhXJosbOxhX9Q/1JoBLvLIIRU.jpg<--->https://sun9-69.userapi.com/pyOjAKdrFAKgWqpTIKZEXFha0RUvEpXWm9UNQQ/G_kGdgc7dcU.jpg<--->https://sun9-35.userapi.com/eHzgnKS2B2L8bWJU7AlsOyfE0Wd1f5xEpZO6Ew/hdGYMF68wjc.jpg<--->https://sun9-7.userapi.com/E-m_HT4x82o_B89eZnhjvKZgvfJhDu6NKjbPVQ/99oWFlxZLss.jpg<--->', '', NULL, '20.10.2020', 'Идет сейчас!', 53, 615435367, 38, NULL, NULL, NULL, NULL, 'Нужно решение. Вариант 12.', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(147299324, 'Электротехника', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Не указан', '10:15', 54, 615435367, 11, NULL, NULL, NULL, NULL, 'Нужно решить рк', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(343242451, 'ПТМ (Подъемно-транспортные машины)', 'Personal', 'Курсовая работа', 'Прислать решение', 'https://sun9-69.userapi.com/FN-fLb0_HeAOBVp0KdHDYysV22X-m8-yJAKavg/Qnz0YGA8qBw.jpg<--->', '', NULL, 'Не знаю', 'Не знаю', 55, 615435367, 40, NULL, NULL, NULL, NULL, 'Долгий ответ', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(279656591, 'Химия', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Сегодня', '13:50', 56, 615435367, 15, NULL, NULL, NULL, NULL, 'первая контрольная по предмету \"химия и материаловедение\". предмет не профильный для меня поэтому контрольная будет легкой', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(102377368, 'Теория машин и механизмов (ТММ)', 'Personal', 'Курсовая работа', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(295729678, 'Математика', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(295729678, 'Математический анализ', 'Personal', 'Домашняя работа', 'Прислать решение', NULL, NULL, 'https://sun9-61.userapi.com/c850224/v850224421/7ccb8/UrBqkIQqMUg.jpg\n', 'Завтра', 'Не знаю', 58, 615435367, 2, 12, 100000, '100 000_45695473', '300000_45695473', 'Тест', 1, 0, NULL, 1, '45695473', NULL, 'хочу 100 000 хотя бы )_45695473', 0),
(257532386, 'Физика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Завтра', '8:30', 60, 615435367, 10, NULL, NULL, '500_11357840,500_11357840', '700_11357840', 'Нужна теория и задачи, что из себя будет представлять билет не знаю', 1, NULL, NULL, 1, ',11357840', '507293609,11357840', 'А гдепропутить?_11357840,Не указан_11357840', NULL),
(175571152, 'Метрология', 'Personal', 'Экзамен/Зачет', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(540756692, 'Военная кафедра', 'Personal', 'Курсовая работа', 'Нормативы', NULL, NULL, NULL, 'Не знаю', 'Не знаю', 62, 615435367, 21, NULL, NULL, NULL, NULL, 'тест', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(247824454, 'Математический анализ', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-13.userapi.com/lwUIeqzlINqW5irUwt_vAkc9P0rHhVcXIidPCw/TRPS5CzM0VY.jpg<--->https://sun9-9.userapi.com/ppx4afcLgBQCsl_c-cItYmCqcUY-dZGxQ2aE3A/9Pt5ivCkufs.jpg<--->https://sun9-68.userapi.com/oBllWvUb1sCyZOAUsO-8lr4CTcy9MmUSdEd0bg/DJTHFbtDg3c.jpg<--->', '', NULL, '23.10', 'Не знаю', 63, 615435367, 43, NULL, NULL, '450_11357840,300_507293609', '650_11357840,500_507293609', 'Разобрался сам', 1, NULL, NULL, 1, ',507293609', '45695473', 'Не указан_11357840,Сделаю все в лучшем виде)_507293609', NULL),
(147299324, 'Электротехника', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Завтра', '10.00', 64, 615435367, 25, 850, 700, '700_136625872', '850_136625872', 'Решить рк', 1, NULL, NULL, 1, '136625872', NULL, 'Пара же будет по времени?_136625872', NULL),
(403562139, 'Детали машин', 'Personal', 'Домашняя работа', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(403562139, 'Детали машин', 'Personal', 'Домашняя работа', 'Прислать решение', NULL, NULL, NULL, 'Не указан', NULL, NULL, 615435367, 26, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(403562139, 'Детали машин', 'Personal', 'Домашняя работа', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(403562139, 'Детали машин', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc403562139_574401092?hash=a012deb9bedd4204d7&dl=GQYDGNJWGIYTGOI:1603309384:fb65a278971b131d6c&api=1&no_preview=1<--->', NULL, 'Не указан', 'Не знаю', NULL, 615435367, 48, NULL, NULL, NULL, NULL, '.', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(403562139, 'Детали машин', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc403562139_574401092?hash=a012deb9bedd4204d7&dl=GQYDGNJWGIYTGOI:1603309661:0e9e3aaf605267d5da&api=1&no_preview=1<--->', NULL, 'Не знаю', 'Не знаю', 67, 615435367, 49, NULL, NULL, NULL, NULL, 'Сколько будет стоить данный типовик (1 вариант)? Нужно максимально подробно расписать, что, как и почему считается, с максимальными пояснениями, так как буду защищаться у препода.', 1, NULL, NULL, 1, NULL, '341478917', NULL, NULL),
(257718208, 'Физика', 'Personal', 'Контрольная работа/РК', 'Сдать за вас', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(208904974, 'Материаловедение', 'Personal', 'Лабораторная работа', 'Прислать решение', '', 'https://vk.com/doc134603709_575050494?hash=69d2acf3e8d08fbba1&dl=GIYDQOJQGQ4TONA:1603359713:0d2ff4e1e394c909e4&api=1&no_preview=1<--->', NULL, '25.10.2020', '16.00', 68, 615435367, 51, NULL, NULL, NULL, NULL, 'Лб 1', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(27273861, 'Экономика', 'Personal', 'Реферат/Доклад/Отчет', 'Прислать решение', 'https://sun9-24.userapi.com/fQUqS2ev6rXaeAtWy_5XY3kHfCLggSIo-gErFQ/2SXuWsoWRsc.jpg<--->', '', NULL, '30.10', 'Не знаю', 69, 615435367, 52, NULL, NULL, NULL, NULL, '2. Содержание. \n3. Введение. \n4. Теоретическая часть. \n \n5. Заключение. \n8. Список использованной литературы. \n9. Приложения. \nОбъем до 20 страниц. \nШрифт – Times New Roman размер 14, интервал 1,5. Абзац 1,25. \nВерхний и нижний отступы – 2,0; правый – 1,5, левый – 3,0. \nТаблица должна содержать номер и заголовок, которые располагаются над ней. \nНомер и название рисунка подписывается под ним. \nСтраницы в работе должны быть пронумерованы, снизу по центру нижнего поля, на первой странице номер не ставится.', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(146613741, 'ПТМ (Подъемно-транспортные машины)', 'Personal', 'Курсовая работа', 'Прислать решение', 'https://sun9-70.userapi.com/SUZSJWjDR2sZf6_nKb9W07TUXR0IP9fTfnfjpg/BSBE-hMY17s.jpg<--->https://sun9-2.userapi.com/PvgMayOdvyJVwuXDdbhov7Z2nBX6zmSqsNf0iA/Ue68tdAlP58.jpg<--->', '', NULL, 'Через неделю', 'Идет сейчас!', 70, 615435367, 53, NULL, NULL, NULL, NULL, 'Наземное оборудование ракетных комплексов', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(212769883, 'Программирование', 'Personal', 'Лабораторная работа', 'Прислать решение', 'https://sun9-10.userapi.com/c5gn9bm0GMUf99hmjj_vLl1-hn3o_7FkHl8EXw/a0wFOMe5YMI.jpg<--->https://sun9-41.userapi.com/QwxN7sA0f4u-eq4qfICN-Wjv6PLHKz8CD5s6PA/gQk17wunHrw.jpg<--->', '', NULL, 'Завтра', '8:00', 71, 615435367, 54, NULL, NULL, '500_11357840', '700_11357840', '10 цифра', 1, NULL, NULL, 1, ',239690133', '172300138', 'Не указан_11357840', NULL),
(294470556, 'Программирование', 'Personal', 'Лабораторная работа', 'Прислать решение', 'https://sun9-53.userapi.com/ZSz0nTL128Lj58W8ieUixXiUImVmThnULbKuOw/xlmxgFOlkQ4.jpg<--->https://sun9-64.userapi.com/ap67j6lEwEu8cnpTxe47UbgCrkTqozqdtmNuEA/LemyLW8a1zs.jpg<--->', '', NULL, 'все, спасибо , нашла, кто сделает.', NULL, NULL, 615435367, 55, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(80011540, 'Теория машин и механизмов (ТММ)', 'Personal', 'Курсовая работа', 'Прислать решение', NULL, NULL, NULL, 'Через неделю', '6. 10', 72, 615435367, 27, NULL, NULL, NULL, NULL, 'Я заказывал у вас работу и хочу вернуть за неё деньги', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(295729678, 'Ок', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(295729678, 'Другое', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(179985890, 'Я запутался)))', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(179985890, 'Элтех', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc179985890_571716596?hash=a1ffbc7424d5c27965&dl=GE3TSOJYGU4DSMA:1603484328:72b107e970983d07a1&api=1&no_preview=1<--->https://vk.com/doc179985890_571716597?hash=b51100e30d7c98d7ea&dl=GE3TSOJYGU4DSMA:1603484328:a9b2b87e61bf11198c&api=1&no_preview=1<--->https://vk.com/doc179985890_571716599?hash=96d70e24e1b924810d&dl=GE3TSOJYGU4DSMA:1603484328:e361e473e315f10a47&api=1&no_preview=1<--->', NULL, 'Не указан', 'Не знаю', 73, 615435367, 60, NULL, NULL, NULL, NULL, 'ZPTNRAPKN', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(193343175, 'Теория машин и механизмов (ТММ)', 'Personal', 'Курсовая работа', 'Прислать решение', '', 'https://vk.com/doc193343175_572252630?hash=861c199b3f9e7605cd&dl=GE4TGMZUGMYTONI:1603538513:8ef111d720992f577b&api=1&no_preview=1<--->https://vk.com/doc193343175_572251428?hash=bd420b3dea6d403eb6&dl=GE4TGMZUGMYTONI:1603538513:879b7d12105e79bf62&api=1&no_preview=1<--->https://vk.com/doc193343175_572252715?hash=0b551a17bc37baa706&dl=GE4TGMZUGMYTONI:1603538513:da01cb0001e9e1ed13&api=1&no_preview=1<--->https://vk.com/doc193343175_572252735?hash=cdc5b332c2e39296f3&dl=GE4TGMZUGMYTONI:1603538513:b3ab332b90b9b9330a&api=1&no_preview=1<--->', NULL, '1.11.2020', 'Идет сейчас!', 74, 615435367, 61, NULL, NULL, NULL, NULL, 'Задание: Выполнить первый лист Курсового проекта \nПрикрепляю: \n1. Пример выполненного листа (документ jpg) \n2. Расчетный файл Excel \n3. Наработки в Компас с полученными графиками положения, скорости и ускорения желоба 5, \nа так же график приведенного момента инерции звеньев (J пр II ) \n4. Само задание в PDF', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(399500927, 'Электротехника', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, '26.10', '14:40', NULL, 615435367, 29, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(296242844, 'Материаловедение', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-4.userapi.com/6p-gEFBrNyamcEtg00cD5xgVl0V9ZrXb_-K8OA/Z-adN57u8lQ.jpg<--->', '', NULL, 'Не знаю', 'Не знаю', 75, 615435367, 63, NULL, NULL, NULL, NULL, 'Мне нужны готовые кр', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(397030529, 'Срок 5дней', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(348419428, 'Теоретическая механика', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc348419428_574388914?hash=2a93464353217f1d8f&dl=GM2DQNBRHE2DEOA:1603646561:b156b0b6a161ac862c&api=1&no_preview=1<--->', NULL, '27.10', 'Не знаю', 76, 615435367, 65, NULL, NULL, '600_8361371', '750_8361371', '70 вариант', 1, NULL, NULL, 1, '8361371', NULL, 'Не указан_8361371', NULL),
(333428655, '', 'Personal', 'Контрольная работа/РК', 'Прислать решение', '', 'https://vk.com/doc333428655_574271201?hash=c3eb9270796ca76725&dl=GMZTGNBSHA3DKNI:1603651066:a668f8e38e617d5953&api=1&no_preview=1<--->', NULL, 'Завтра', 'Идет сейчас!', 77, 615435367, 66, NULL, NULL, NULL, NULL, 'ВСЕ НАДО', 1, NULL, NULL, 1, NULL, '413452302,113646923', NULL, NULL),
(212769883, 'Математический анализ', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-37.userapi.com/fX8022ILJrw2MXGRugrIXbaIDv3aUSX-bARb1w/ROmYq0mTTAQ.jpg<--->https://sun9-30.userapi.com/RSKvNXnfsbEUCgAG_yIubp8k3aswTfADyn9doQ/GF8fE-ZP-8o.jpg<--->', '', NULL, '30.10', '21:00', 78, 615435367, 67, NULL, NULL, '650_239690133,1000_507293609,300_11357840', '800_239690133,1150_507293609', '2-5 номер', 1, NULL, NULL, 1, ',11357840', NULL, 'Готов сделать за 650_239690133,Не указан_507293609,Не указан_11357840', NULL),
(477825880, 'Физика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', '', 'https://vk.com/doc477825880_571696793?hash=58f224fdba0d31c025&dl=GQ3TOOBSGU4DQMA:1603697739:19593df7150ea9da47&api=1&no_preview=1<--->', NULL, 'Сегодня', '15:40', 79, 615435367, 68, NULL, NULL, NULL, NULL, '1) 15:40 по мск \n2) 30 минут - 1 час \n3) 2-3 теорий, то есть вопросы и 2-3 задачи решать \nприлагаю похожие вопросы и задачи', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(228760341, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(213085724, 'Метрология', 'Personal', 'Домашняя работа', 'Прислать решение', '', 'https://vk.com/doc213085724_572232187?hash=3bf3f17777e3b9834e&dl=GIYTGMBYGU3TENA:1603701538:e697285a85548ae813&api=1&no_preview=1<--->https://vk.com/doc213085724_572232191?hash=df8b8bece38f70be20&dl=GIYTGMBYGU3TENA:1603701538:6f41470b04a8f37cf9&api=1&no_preview=1<--->', NULL, 'Через неделю', 'Не знаю', 80, 615435367, 70, NULL, NULL, NULL, NULL, 'Высокая цена', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(141741865, 'Электротехника', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-32.userapi.com/JhlFgcakV1x4PhPipy0P3HrtARKLT2Fg0uRagw/Wefzvt3DIbc.jpg<--->', '', NULL, 'Не знаю', '12:00', 81, 615435367, 71, NULL, NULL, NULL, NULL, 'Методичка есть, отправлю', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(165289838, 'Физика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-6.userapi.com/jjttgHWRTzFb4MU2e_qgK5EwUQF4z2DwAkfkaQ/mLQo0R9ggQo.jpg<--->', '', NULL, '26.10 до 12:50', 'Идет сейчас!', NULL, 615435367, 72, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(295729678, 'Теория вероятностей и математическая статистика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, 'Сегодня', 'Идет сейчас!', NULL, 615435367, 30, NULL, NULL, NULL, NULL, 'Аааааа', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(388923832, 'Материаловедение', 'Personal', 'Экзамен/Зачет', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(184434343, 'Дифференциальные уравнени', 'Personal', 'Контрольная работа/РК', 'Прислать решение', '', 'https://vk.com/doc184434343_572358462?hash=42139958d27c1380c7&dl=GE4DINBTGQZTIMY:1603796978:cf604bf40fe9ebfe46&api=1&no_preview=1<--->https://vk.com/doc184434343_572358464?hash=1008be95ca9cee7d01&dl=GE4DINBTGQZTIMY:1603796978:7fe42012ed999d3d02&api=1&no_preview=1<--->', NULL, 'Сегодня', '7 заданий хотя бы решить', 82, 615435367, 75, NULL, NULL, NULL, NULL, 'да, пока первые 5', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(157002499, 'Физик', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(157002499, '', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(556048701, 'Сопротивление материало', 'Personal', 'Домашняя работа', 'Прислать решение', 'https://sun9-31.userapi.com/ydExoHLuyFztXvhfrbblWwpQpeiUqzV1hoeF9Q/xI0bo8NfCbo.jpg<--->https://sun9-10.userapi.com/rtriemSXR7K7oYsvsv6aCv_Ymehfhv0-DBv0BQ/6ghBxfI_aW8.jpg<--->', '', NULL, 'Завтра', 'Идет сейчас!', 83, 615435367, 78, NULL, NULL, NULL, NULL, 'Нужно решение', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(556048701, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(257718208, 'Физик', 'Personal', 'Контрольная работа/РК', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(613563975, 'В', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(613563975, 'sss', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(613563975, 'Военная кафедр', 'Personal', 'Дипломная работа', 'Диктовка', NULL, NULL, NULL, 'Не знаю', 'Не знаю', 84, 615435367, 32, NULL, NULL, NULL, NULL, 'уу', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3691932, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(40887756, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(137420091, 'Информатика', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-29.userapi.com/ToNApPkcqsvXcHss89sk3zcKE-PkJJXOybPA-A/-BhZ1ZHXRl8.jpg<--->', '', NULL, 'Завтра', 'Не знаю', 85, 615435367, 87, NULL, NULL, NULL, NULL, 'Нужно решить 3 номера \nА в дальнейшем защитить работу', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(87599750, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1),
(257718208, 'Физика', 'Personal', 'Контрольная работа/РК', 'Сдать за вас', '', 'https://vk.com/doc257718208_576760618?hash=a3e49e80f79927dc2c&dl=GI2TONZRHAZDAOA:1603885203:e1b6b571d4f05a1658&api=1&no_preview=1<--->', NULL, 'Завтра', '18:00', 86, 106541016, 89, NULL, NULL, NULL, NULL, 'само рк сдано, но нужно его защитить. Защита проходит без камер в аудиоформате. Кто-то заходит вместо меня и отвечает на вопросы от препода. Найдется такой специалист?', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(368259581, 'null', 'Personal', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 615435367, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 0),
(202176297, 'Гидравлика', 'Declined', 'Домашняя работа', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(78500404, 'Сопротивление материалов', 'InProcessing', 'Домашняя работа', 'Прислать решение', 'https://sun9-73.userapi.com/ff5atsIg1h3SDV4w7wLQXf5IbDs6tTioDC-_EA/SxKFr7_yRjM.jpg<--->https://sun9-4.userapi.com/XgZVE1Ng99eihBFuQovQto7p3bX3RfsPYXrePw/DCC14cy-29I.jpg<--->https://sun9-41.userapi.com/YfFcG5dnJdnemtOCynFmpUi3KJUr8-4q2v7NmQ/U6PCioTOP_Q.jpg<--->https://sun9-52.userapi.com/XF99ZST5-GbJgd0eF0OB-t8sxollUaVV29__0w/HWWclOpMi8w.jpg<--->https://sun9-39.userapi.com/rfcTv4qx9cdxz3ViNYHXPdpMd_RDQxYlkpj0Vg/RdFTG8beZz8.jpg<--->https://sun9-74.userapi.com/Wsk3cPcx1R_6XDdl7jCnRlPt82YgUEXWqn5CFA/e4RyopWIYcw.jpg<--->', '', NULL, '28.10', 'Не знаю', 87, NULL, 91, NULL, NULL, '400_507293609,500_8361371', '550_507293609,650_8361371', 'А какие есть промокоды? \nНу а все что надо я прислал. Работу сделал, а вопросов не понял, нужна помощь', 1, NULL, NULL, 1, ',8361371', '187687343,498977670,435193574,204514724', 'Просто очень грязно написано и в некоторых местах неправильно_507293609,со всем помогу разобраться, цену пока примерную пишу_8361371', NULL),
(227915400, 'Механика жидкостей и газов (МЖГ)', 'Declined', 'Домашняя работа', 'Прислать решение', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(227915400, 'Механика жидкостей и газов (МЖГ)', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-56.userapi.com/f-W-xefldhiPUpOAeWL2Fral11nnDWLao3IoYQ/9ae5muTmlX8.jpg<--->', '', NULL, 'Сегодня', '17:30', 90, 513757464, 93, NULL, NULL, NULL, NULL, 'Первый вопрос теоретический, второй вопрос- задача', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(264959482, 'Материаловедение', 'Personal', 'Контрольная работа/РК', 'Прислать решение', 'https://sun9-45.userapi.com/7iwXoPBm80I-mFeUzhCioAjrNM-NSJYa_9f54g/htKmNWG70t4.jpg<--->', '', NULL, 'Сдать надо в 17:00', 'Идет сейчас!', 89, 513757464, 94, NULL, NULL, NULL, NULL, 'Весь вариант 5', 1, NULL, NULL, 1, NULL, NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
